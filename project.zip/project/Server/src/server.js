import express, { query } from 'express';
import env from 'dotenv';
import pg from 'pg';
import {dirname, resolve} from 'path';
import { fileURLToPath } from 'url';
import bodyParser from 'body-parser';
import multer from 'multer';
import session from 'express-session';
import connectPgSimple from 'connect-pg-simple';
import { error } from 'console';


env.config(); //configuration the env file
const app = express(); //create new express application
const port = 3000;
console.log("Hello world, server works");
const db = new pg.Client({
    user: process.env.PG_USER,
    host: process.env.PG_HOST,
    database: process.env.PG_DB,
    password: process.env.PG_PW,
    port: process.env.portDB
});
db.connect();
const directoryName = dirname(fileURLToPath(import.meta.url));
var indexIdentifier = directoryName.lastIndexOf("project");
var directoryCut = directoryName.substring(0, indexIdentifier+7);
//console.log(directoryCut);
const storageForAvatar = multer.diskStorage({
    destination: (req, file, cb)=>{
        cb(null, './assets/images/avatarOfUser');
    },
    filename: (req, file, cb)=>{
        cb(null, file.originalname);
        console.log(`The image of ${file.originalname} has been uploaed to database`);
    }
});
const upload1 = multer({storage: storageForAvatar});


//Using middleware
app.use(bodyParser.urlencoded({extended: true}));
app.use(express.static("../..//Client/assets"));
app.use(express.static("../../Client/views"));
app.use(session({
    secret: 'secret-key',
    resave: false,
    saveUninitialized: false,
    cookie: {maxAge: 600000, httpOnly:false} //10mins
}));
app.use(express.json());


app.get("/", async(req, res)=>{ // log in page
    res.sendFile(directoryCut+"/Client/views/test.html");
    console.log("Rendering sign in page...");
    console.log(req.session);
});

app.post("/", async (req, res) => {
    try {
        let usernameEnter = req.body.username;
        let passwordEnter = req.body.password;
        const resultQuery = await db.query("SELECT * FROM users WHERE username = $1", [usernameEnter]);
        const user = resultQuery.rows[0];
        if (!user) {
            console.log("No user found!");
            res.status(404).json({ error: "User not found" });
        } else if (user.password !== passwordEnter) {
            console.log("Wrong password");
            res.status(401).json({ error: "Wrong password" });
        } else {
            if(usernameEnter === "masterKay"){
                let sessionData = req.session;
                sessionData.isAuth = true;
                sessionData.username = usernameEnter;
                res.status(200).json({message: "Rendering master mode..."})
            }else{
                console.log(`Welcome user ${user.username}`);
                let sessionData = req.session;
                sessionData.isAuth = true;
                sessionData.username = usernameEnter;
                console.log(sessionData);
                console.log(req.sessionID);
                res.status(200).json({ message: `Welcome user ${user.username}` });
            }
        }
    } catch (error) {
        console.error("Error:", error);
        res.status(500).json({ error: "Server error" });
    }
});

app.get("/signup", async(req, res)=>{
    res.sendFile(directoryCut + "/Client/views/test.html");
    console.log("Rendering signup page...");
});

app.post("/signup", async(req, res)=>{
    console.log(req.body);
    let usernameEnter = req.body.username;
    let passwordEnter = req.body.password;
    let confirmpwEnter = req.body.confirmpw;
    const resultQuery = await db.query("SELECT username FROM users WHERE username = $1", [usernameEnter]);
    if(resultQuery.rows.length>0){
        console.log("User has existed in the database already");
        res.status(409).json({error: "User existed"});
    }else{
        if(passwordEnter !== confirmpwEnter){
            console.log("Conflict confirmation");
            res.status(409).json({error: "Password conflicts with confirm password"});
        }else{
            try{
                await db.query("BEGIN");
                await db.query("SET TRANSACTION ISOLATION LEVEL SERIALIZABLE");
                await db.query("INSERT INTO users (username, password, item_bought) VALUES ($1, $2, 0)", [usernameEnter, passwordEnter]);
                await db.query("COMMIT");
                console.log("Commited this change to db");
            }catch(error){
                await db.query("ROLLBACK");
                console.error("Transaction fail, error is: ", error);
                res.status(500).json({error: error});
            }finally{
                console.log("Successfully registered");
                res.status(200).json({message: "Successfully registered"});
            }
        }
    }
})

app.get("/main", async(req, res)=>{
    const isAuthorized = req.session.isAuth;
    console.log(isAuthorized);
    if(!isAuthorized){
        res.status(401).json({error: "Unauthorized"});
    }else{
        res.sendFile(directoryCut + "/Client/views/secretTest.html");
    }
});

app.get("/main/logout", async(req, res)=>{
    req.session.destroy((err)=>{
        if(err){    
            console.log(err);
            res.status(500).json({error: err})
        }else{
            res.redirect("/"); 
        }
    })
});

app.get("/main/userInfo", async(req, res)=>{
    try{
        res.sendFile(directoryCut + "/Client/views/test.html");//rendering the page of user information
        console.log("Rendering the pge userInfo");
    }catch(error){
        console.log(error);
        res.status(500).json({error: error});
    }
})

app.get("/main/userInfo/changepw", async(req,res)=>{
    try{
        res.sendFile(directoryCut + "/Client/views/test.html"); //rendering the changepass
        console.log("User wanting to change pw...");
    }catch(error){
        console.log(error);
        res.status(500).json({error: error});
    }
})

app.post("/main/userInfo/changepw", async(req,res)=>{
    let userHere = req.session.username;
    console.log(userHere);
    let passwordEnter = req.body.password;
    let newPassword = req.body.newPassword;
    let confirmNewPW = req.body.confirmNewPW;
    const queryResult = await db.query("SELECT password FROM users WHERE username = $1", [userHere]);
    const pw = queryResult.rows[0];
    if(pw.password !== passwordEnter){
        console.log("Wrong password");
        res.status(401).json({error: "Wrong password"});
    }else if (newPassword !== confirmNewPW){
        console.log("Password do not match");
        res.status(409).json({error: "Password conflict"});
    }else{
        try{
            await db.query("BEGIN");
            await db.query("SET TRANSACTION ISOLATION LEVEL SERIALIZABLE");
            await db.query("UPDATE users SET password = $1 WHERE username = $2", [newPassword, userHere]);
            await db.query("COMMIT");
            console.log("Commit the new password changes");
        }catch(error){
            console.log(error);
            await db.query("ROLLBACK");
            res.status(500).json({error: error});
        }finally{
            console.log("Finish update the new password");
            res.status(200).json({message: "Update new password successfully, please return to login page"});
        }
    }
})

app.get("/api/users", async(req, res)=>{
    const user = req.session.username;
    const queryResult = await db.query("SELECT username, item_bought FROM users WHERE username = $1", [user]);
    if(!queryResult.rows[0]){
        res.status(500).json({error: error});
    }
    let usernameData = queryResult.rows[0].username;
    let itemCountData = queryResult.rows[0].item_bought;
    res.json({
        username: usernameData,
        item_bought: itemCountData
    })
    console.log("sending user info...");
})

app.delete("/user", async(req, res)=>{
    const user = req.session.username;
    try{
        await db.query("BEGIN");
        await db.query("SET TRANSACTION ISOLATION LEVEL SERIALIZABLE");
        if(!user){
            res.status(401).json({error: "Unauthorized user, should not proceed"})
        }
        await db.query("DELETE FROM users WHERE username = $1", [user]);
        await db.query("COMMIT");
        console.log("Committing deleting an account");
        req.session.destroy((error)=>{
            if(error){
                console.log(error);
                res.status(501).json({error: "Server error"});
            }
        });
        res.status(200).json({message: "Successfully delete this account from user " + user + ". Returning to the login page..."});
    }catch(error){
        console.log(error);
        await db.query("ROLLBACK");
        res.status(500).json({error: error});
    }
})

app.get("/items/:id", async(req, res)=>{
    const id = req.params.id;
    const queryResult = await db.query("SELECT * FROM items WHERE id = $1", [id]);
    console.log(queryResult.rows[0]);
    if(!queryResult.rows[0]){
        console.log("This item id does not exist");
        res.status(404).json({error: "Not found item"});
    }else{
        console.log(queryResult.rows[0]);
        res.status(200).json({
            image_path: queryResult.rows[0].image,
            item_name: queryResult.rows[0].name,
            price: queryResult.rows[0].price,
            stock: queryResult.rows[0].stock
        });
    }
})

app.post("/main/purchase/:id", async(req, res)=>{
    const itemID = req.params.id;
    let quantity = req.body.quantity;
    let address = req.body.address;
    quantity = parseInt(quantity);
    const buyer = req.session.username;
    try{
        await db.query("BEGIN")
        await db.query("SET TRANSACTION ISOLATION LEVEL SERIALIZABLE");
        const queryResult = await db.query("SELECT price, stock FROM items WHERE id = $1", [itemID]);
        let data = queryResult.rows[0];
        let priceItem = data.price;
        let itemStock = data.stock;
        if(quantity > itemStock){
            res.status(409).json({error: "Not enough items in the stock for the purchase"});
        }else{
            let total_spent = quantity * priceItem;
            let now = new Date();
            await db.query("INSERT INTO orders (buyer, itemid, quantity, total_spent, purchase_time, ship_to) VALUES ($1, $2, $3, $4, $5, $6)"
                ,[buyer, itemID, quantity, total_spent, now, address]);
            let stock_left = itemStock - quantity;
            await db.query("UPDATE items SET stock = $1 WHERE id = $2", [stock_left, itemID]);
            const queryUser = await db.query("SELECT item_bought FROM users WHERE username = $1", [buyer]);
            let dataHere = queryUser.rows[0].item_bought;
            dataHere = parseInt(dataHere)
            dataHere = dataHere + quantity;
            await db.query("UPDATE users SET item_bought = $1 WHERE username = $2", [dataHere, buyer]);
            await db.query("COMMIT");
            res.status(200).json({message: "Successfully purchased"});
        }
    }catch(err){
        console.log(err);;
        await db.query("ROLLBACK");
        res.status(500).json({error: err});
    }
})

app.get("/api/totalItem", async(req, res)=>{ //returning the total number of items type
    var queryRes = await db.query("SELECT COUNT(id) FROM items");
    try{
        res.status(200).json({total_num_item_type: queryRes.rows[0].count})
    }catch(error){
        console.log(error);
        res.status(500).json({error: error});
    }
})

app.get("/admin", async(req, res)=>{
    if(req.session.username === "masterKay"){
        res.sendFile(directoryCut + "/Client/views/test.html");
    }else{
        res.status(401).json({error: "Bad credentials, unauthorized"});
    }
})

app.post("/admin/addItem", async(req, res)=>{
    if(req.session.username !== "masterKay"){
        console.log("Unauthorized");
        res.status(401).json({error: "Unautorized"});
    }else{
        let itemID = req.body.id;
        let image_url = req.body.image_url;
        let name = req.body.name;
        let price = req.body.price;
        let stock = req.body.stock;
        try{
            await db.query("BEGIN");
            await db.query("SET TRANSACTION ISOLATION LEVEL SERIALIZABLE");
            await db.query("INSERT INTO items VALUES($1, $2, $3, $4, $5)",[itemID, image_url, name, price, stock]);
            await db.query("COMMIT");
            console.log("Committed the new added product");
            res.status(200).json("Successfully added in");
        }catch(error){
            console.log(error);
            await db.query("ROLLBACK");
            res.status(500).json({error: "System error"});
        }
    }
})

app.delete("/admin/deleteItems/:id", async(req, res)=>{
    if(req.session.username !== "masterKay"){
        console.log("Unauthorized");
        res.status(401).json({error: "Unauthorized"});
    }else{
        try{
            var id = req.params.id;
            await db.query("BEGIN");
            await db.query("SET TRANSACTION ISOLATION LEVEL SERIALIZABLE")
            await db.query("DELETE FROM items WHERE id = $1", [id]);
            await db.query("COMMIT");
            console.log("Done deleting");
            res.status(200).json({message: "Successfully deleted item"});
        }catch(error){
            console.log("ERROR occurs");
            console.log(error);
            await db.query("ROLLBACK");
            res.status(500).json({error: "System error"});
        }
    }
})

app.patch("/admin/edit/:id", async(req,res)=>{
    var id = req.params.id;
    if(req.session.username !== "masterKay"){
        console.log("Unauthorized");
        res.status(401).json({message: "Unauthorized"});
    }else{
        try{
            let image_url = req.body.image_url;
            let name = req.body.name;
            let price = req.body.price;
            let stock = req.body.stock;
            await db.query("BEGIN");
            await db.query("SET TRANSACTION ISOLATION LEVEL SERIALIZABLE");
            await db.query("UPDATE items SET image = $1, name = $2, price = $3, stock = $4 WHERE id = $5", [image_url, name, price, stock, id]);
            await db.query("COMMIT");
            console.log("Commit new edit change");
            res.status(200).json({message: "Update OK"});
        }catch(error){
            console.log(error);
            await db.query("ROLLBACK");
            res.status(500).json({error: "Server error"});
        }
    }
})

const server = app.listen(port, ()=>{
    console.log(`Server is running on port ${port}.`);
})
