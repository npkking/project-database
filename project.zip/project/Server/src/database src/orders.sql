CREATE TABLE orders(
    orderID SERIAL,
    buyer TEXT,
    itemID INTEGER,
    quantity INTEGER,
    purchase_time TIMESTAMP,
    total_spent FLOAT,
    FOREIGN KEY(itemID) REFERENCES items(id),
    FOREIGN KEY(buyer) REFERENCES users(username),
	PRIMARY KEY (orderID)
);