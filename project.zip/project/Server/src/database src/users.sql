CREATE TABLE users(
  	username VARCHAR(50),
  	password VARCHAR(50),
	  item_bought INTEGER,
  	UNIQUE(username),
  	PRIMARY KEY (username) 
);