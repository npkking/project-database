CREATE TABLE items(
    id INTEGER PRIMARY KEY,
    image TEXT,
    name TEXT,
    price FLOAT,
    stock INTEGER
);